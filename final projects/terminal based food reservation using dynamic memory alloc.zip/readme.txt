-manager pass is 1135
-system will save orders but when you rerun the code previous orders will be deleted
-you can see saved orders in order.txt but the costumers cannot see the list.
-in first run you have to add menu via manager>add new list(2)>...

