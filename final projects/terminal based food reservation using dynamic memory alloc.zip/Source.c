#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

struct food {
	char name[20];
	int price;
};
const char* struct_write_format = "(%s,%d)\n";
const char* struct_read_format = "(%[^,],%d)\n";


//code 0
void welcome(int *page) {
	int temp;
	printf("################## Home ##################\n");
	printf("please choose one of the followings\n");
	printf("1. order food\n");
	printf("2. manage system and food menu\n");
	printf("3. software update and optimization\n");
	printf("4. about and exit\n");
	printf("=========================================\n\n");
	while (1) {
		scanf("%d", &temp);
		if (temp < 5 && temp > 0) {
			*page = temp;
			break;
		}
		else {
			printf("invalid input! try again: ");
		}
	}
}
//code 4
void about() {
	printf("################## about ##################\n");
	printf("Neutron software development LLC all rights reserved \n");
	printf("Ordering system. version 1\n");
	printf("thanks for choosing us, have a delightful day/night");
	printf("\n=========================================\n");
}
//code 3
void update(int* page) {
	int temp;
	printf("################## update ##################\n");
	printf("you have the latest version \n");
	printf("Ordering system. version 1\n\n");
	printf("0:back to home             4:exit");
	printf("\n=========================================\n");
	scanf("%d", &temp);
	while (1) {
		if (temp == 0 || temp == 4) {
			*page = temp;
			break;
		}
		else {
			printf("invalid input! try again: ");
		}
	}
}
//code 2
void manage1(int* page , int* pin, int* income) {
	int temp;
	int input;
	printf("################## Manage1 ##################\n");
	printf("1. see available foods\n");
	printf("2. enter food list again (current list will be deleted)\n");
	printf("3. add to menu\n");
	printf("4. change pin code\n");
	printf("5. see today income\n\n");
	printf("0:back to menu\n");
	printf("----------------------------------------------\n");
	while (1) {
		scanf("%d", &input);
		if (input == 0) {
			*page = 0;
			printf("=========================================\n");
			break;
		}
		else if (input == 4) {
			printf("enter the new pin code:");
			scanf("%d", &temp);
			*pin = temp;
			printf("changed successfully\n");
		}
		else if (input == 1) {
			int count=0;
			FILE* c;
			c = fopen("c.txt", "r");
			fscanf(c, "%d", &count);
			fclose(c);
			if (count == 0) {
				printf("there is no food option here!\ngo to the edit and enter section to add\n");
			}
			else {
				printf("there are currently %d foods registered\n", count);
				struct food* temp;
				temp = (struct food*)malloc(sizeof(struct food));
				//struct food temp;
				c = fopen("save.txt", "r");
				for (int i = 0; i < count; i++) {
					fscanf(c, struct_read_format, temp->name, &temp->price);
					printf("%d. %s:      %d$\n", i+1, temp->name, temp->price);
				}
				fclose(c);
				free(temp);
				printf("for adding and changing the list please go to the edit section\n");
			}
		}
		else if (input == 2) {
			int z = 0;
			struct food* temp2;
			temp2 = (struct food*)malloc(sizeof(struct food));
			printf("how many foods you want to add?\n");
			scanf("%d", &z);
			FILE* c2;
			c2 = fopen("c.txt", "w");
			fprintf(c2, "%d", z);
			fclose(c2);
			c2 = fopen("save.txt", "w");
			while (z>0) {
				printf("enter food's name: ");
				scanf("%s", temp2->name);
				printf("and the price in dollars is: ");
				scanf("%d", &temp2->price);
				fprintf(c2, struct_write_format, temp2->name, temp2->price);
				z -= 1;
			}
			fclose(c2);
			free(temp2);
			printf("done\n");
		}
		else if (input == 3) {
			int count1 = 0;
			int y = 0;
			struct food* temp3;
			temp3 = (struct food*)malloc(sizeof(struct food));
			printf("how many foods you want to add to previous list?\n");
			scanf("%d", &y);
			FILE* c3;
			c3 = fopen("c.txt", "r");
			fscanf(c3, "%d", &count1);
			y = y + count1;
			fclose(c3);
			c3 = fopen("c.txt", "w");
			fprintf(c3, "%d", y);
			fclose(c3);
			c3 = fopen("save.txt", "a");
			y = y - count1;
			while (y > 0) {
				printf("enter food's name: ");
				scanf("%s", temp3->name);
				printf("and the price in dollars is: ");
				scanf("%d", &temp3->price);
				fprintf(c3, struct_write_format, temp3->name, temp3->price);
				y -= 1;
			}
			fclose(c3);
		}
		else if (input == 5) {
			printf("today we,ve sold %d dollars\n", *income);
		}
		else {
			printf("wrong input! try again: ");
		}
		printf("what next?: ");
	}
}
//check function
void check() {
	FILE* a;
	a = fopen("c.txt", "r");
	if (a == NULL) {
		a = fopen("c.txt", "w");
		fprintf(a, "%d", 0);
		fclose(a);
		a = fopen("save.txt", "w");
		fclose(a);
	}
	a = fopen("order.txt", "w");
	fclose(a);
}
//code1
void order(int* page,int* income) {
	int input;
	int name[20];
	int count = 0;
	FILE* c;
	c = fopen("c.txt", "r");
	fscanf(c, "%d", &count);
	fclose(c);
	printf("################## order ##################\n");
	printf("there are currently %d foods available to order\n", count);
	struct food* temp;
	temp = (struct food*)malloc(sizeof(struct food));
	//struct food temp;
	c = fopen("save.txt", "r");
	for (int i = 0; i < count; i++) {
		fscanf(c, struct_read_format, temp->name, &temp->price);
		printf("%d. %s:      %d$\n", i + 1, temp->name, temp->price);
	}
	fclose(c);
	printf("\n0:back to menu\n");
	printf("----------------------------------------------\n");
	while (1){
		printf("which one do you want to order? <0 for return>: ");
		scanf("%d", &input);
		if (input == 0) {
			*page = 0;
			printf("=========================================\n");
			free(temp);
			break;
		}
		else if (input > count || input < 0) {
			printf("invalid input! try again: ");
		}
		else {
			printf("enter your name: ");
			scanf(" %s", name);
			FILE* d;
			d = fopen("order.txt", "a");
			c = fopen("save.txt", "r");
			input -= 1;
			for (int i = 0; i < count; i++) {
				fscanf(c, struct_read_format, temp->name, &temp->price);
				if (i == input) {
					fprintf(d, struct_write_format, name, i);
					printf("dear %s, you have ordered %s successfully\nplease pay %d$\n",name, temp->name, temp->price);
					*income += temp->price;
					i = count + 1;
				}
			}
			fclose(d);
			fclose(c);
		}
	}
}


int main() {
	int income = 0;
	int input = 0;
	int page = 0;
	//highest security ever LOL
	int pin_code = 1135;
	int temp;
	//..........................
	//checking lists availability
	check();
	//--------------------------
	while (page > -1) {
		if (page == 0) {
			welcome(&page);
		}
		else if (page == 4) {
			about();
			break;
		}
		else if (page == 3) {
			update(&page);
		}
		else if (page == 2) {
			printf("Enter Admin's pin code: ");
			while (1) {
				scanf("%d", &temp);
				if (temp == pin_code) {
					printf("access granted\n\n");
					manage1(&page,&pin_code,&income);
					break;
				}
				else if (temp == 0) {
					page = 0;
					break;
				}
				else {
					printf("wrong pin code! type 0 to exit");
				}
			}
		}
		else if (page == 1) {
			order(&page,&income);
		}
		else {
			printf("something is not right! try again\n");
			page = 0;
		}
	}
}
